using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public enum PowerUpType
    {
        PaddleSize,
        DoubleScore,
        MultiBall
    }
    
    public PowerUpType powerUpType;
    public float fallSpeed = 1.5f;
    
    void Update()
    {
        transform.Translate(Vector3.down * fallSpeed * Time.deltaTime);
        
        if (transform.position.y < -5.5f)
            Destroy(gameObject);
    }
    
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Platform"))
        {
            if (PowerUpManager.Instance != null)
                PowerUpManager.Instance.ActivatePowerUp(powerUpType);
            Destroy(gameObject);
        }
    }
}