using UnityEngine;

public class Brick : MonoBehaviour
{
    public int scoreValue = 10;
    public AudioClip breakClip;
    public GameObject explosionEffect;
    public GameObject powerUpPrefab;        
    public float powerUpDropChance = 0.4f;  
    
    private bool isDestroyed = false;
    private AudioSource audioSource;
    
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null && breakClip != null)
            audioSource = gameObject.AddComponent<AudioSource>();
    }
    
    void OnCollisionEnter(Collision collision)
    {
        if (isDestroyed) return;
        
        if (collision.gameObject.CompareTag("Ball"))
        {
            isDestroyed = true;
            
            if (breakClip != null && audioSource != null)
                audioSource.PlayOneShot(breakClip);
            
            if (explosionEffect != null)
                Instantiate(explosionEffect, transform.position, Quaternion.identity);
            
            TryDropPowerUp();
            
            GameManager.Instance.AddScore(scoreValue);
            GameManager.Instance.BrickDestroyed();
            Destroy(gameObject, 0.1f);
        }
    }
    
    void TryDropPowerUp()
    {
        if (Random.value > powerUpDropChance) return;
        
        if (powerUpPrefab != null)
        {
            GameObject powerUp = Instantiate(powerUpPrefab, transform.position, Quaternion.identity);
            
            PowerUp powerUpScript = powerUp.GetComponent<PowerUp>();
            if (powerUpScript != null)
            {
                int randomType = Random.Range(0, 3);
                powerUpScript.powerUpType = (PowerUp.PowerUpType)randomType;
                
                Renderer rend = powerUp.GetComponent<Renderer>();
                if (rend != null)
                {
                    switch (powerUpScript.powerUpType)
                    {
                        case PowerUp.PowerUpType.PaddleSize:
                            rend.material.color = Color.green;
                            break;
                        case PowerUp.PowerUpType.DoubleScore:
                            rend.material.color = Color.yellow;
                            break;
                        case PowerUp.PowerUpType.MultiBall:
                            rend.material.color = Color.red;
                            break;
                    }
                }
            }
        }
    }
}