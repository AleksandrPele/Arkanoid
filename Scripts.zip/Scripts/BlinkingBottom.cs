using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class BlinkinBottom : MonoBehaviour
{
    public float blinkSpeed = 1f;
    private Image buttonImage;
    private Color originalColor;
    
    void Start()
    {
        buttonImage = GetComponent<Image>();
        originalColor = buttonImage.color;
        StartCoroutine(Blink());
    }
    
    IEnumerator Blink()
    {
        while (true)
        {
            float alpha = Mathf.PingPong(Time.time * blinkSpeed, 0.5f) + 0.3f;
            buttonImage.color = new Color(originalColor.r, originalColor.g, originalColor.b, alpha);
            yield return null;
        }
    }
}
