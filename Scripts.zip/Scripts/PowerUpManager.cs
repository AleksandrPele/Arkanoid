using UnityEngine;
using System.Collections;

[DefaultExecutionOrder(-100)]
public class PowerUpManager : MonoBehaviour
{
    public static PowerUpManager Instance;
    
    private bool doubleScoreActive = false;
    private bool paddleSizeActive = false;
    private int currentMultiplier = 1;
    private float originalPaddleScaleX;
    private GameObject paddle;
    
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    void Start()
    {
        paddle = GameObject.FindGameObjectWithTag("Platform");
        if (paddle != null)
            originalPaddleScaleX = paddle.transform.localScale.x;
    }
    
    public void ActivatePowerUp(PowerUp.PowerUpType type)
    {
        switch (type)
        {
            case PowerUp.PowerUpType.PaddleSize:
                StartCoroutine(ActivatePaddleSize());
                break;
            case PowerUp.PowerUpType.DoubleScore:
                StartCoroutine(ActivateDoubleScore());
                break;
            case PowerUp.PowerUpType.MultiBall:
                ActivateMultiBall();
                break;
        }
    }
    
    IEnumerator ActivatePaddleSize()
    {
        if (paddleSizeActive) yield break;
        paddleSizeActive = true;
        
        if (paddle != null)
            paddle.transform.localScale = new Vector3(originalPaddleScaleX * 2, paddle.transform.localScale.y, paddle.transform.localScale.z);
        
        yield return new WaitForSeconds(30f);
        
        if (paddle != null)
            paddle.transform.localScale = new Vector3(originalPaddleScaleX, paddle.transform.localScale.y, paddle.transform.localScale.z);
        paddleSizeActive = false;
    }
    
    IEnumerator ActivateDoubleScore()
    {
        if (doubleScoreActive) yield break;
        doubleScoreActive = true;
        currentMultiplier = 2;
        
        yield return new WaitForSeconds(30f);
        
        currentMultiplier = 1;
        doubleScoreActive = false;
    }
    
    void ActivateMultiBall()
    {
        if (paddle == null)
            paddle = GameObject.FindGameObjectWithTag("Platform");
        
        if (paddle == null) return;
        
        BallController originalBall = FindObjectOfType<BallController>();
        if (originalBall == null) return;
        
        GameObject newBall = Instantiate(originalBall.gameObject, paddle.transform.position + new Vector3(0, 0.5f, 0), Quaternion.identity);
        BallController newBallController = newBall.GetComponent<BallController>();
        
        if (newBallController != null)
        {
            newBallController.paddle = paddle;
            
            newBallController.isLaunched = false;
            
            Rigidbody rb = newBall.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.velocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
            
            newBall.transform.position = new Vector3(
                paddle.transform.position.x,
                paddle.transform.position.y + 0.5f,
                0f
            );
            
            if (BallMultiplierManager.Instance != null)
                BallMultiplierManager.Instance.AddBall(newBallController);
        }
    }
    
    public int GetScoreMultiplier()
    {
        return currentMultiplier;
    }
}