using UnityEngine;
using System.Collections;

public class PlatformController : MonoBehaviour
{
    public float speed = 8f;
    public float leftBound = -7.2f;
    public float rightBound = 7.2f;
    
    private Rigidbody rb;
    
    
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }
    
    void Update()
    {
        float move = Input.GetAxis("Horizontal");
        rb.velocity = new Vector3(move * speed, 0, 0);
        
        Vector3 pos = transform.position;
        pos.x = Mathf.Clamp(pos.x, leftBound, rightBound);
        transform.position = pos;
    }
    
    public void HitAnimation()
    {
        StartCoroutine(FlashWhite());
    }
    
    IEnumerator FlashWhite()
    {
        yield return new WaitForSeconds(0.1f);
    }
}