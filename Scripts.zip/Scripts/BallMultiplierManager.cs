using UnityEngine;
using System.Collections.Generic;

public class BallMultiplierManager : MonoBehaviour
{
    public static BallMultiplierManager Instance;
    public GameObject ballPrefab;  
    
    private List<BallController> balls = new List<BallController>();
    private bool isRespawning = false;
    
    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }
    
    void Start()
    {
        BallController[] allBalls = FindObjectsOfType<BallController>();
        foreach (BallController ball in allBalls)
        {
            balls.Add(ball);
        }
    }
    
    public void AddBall(BallController ball)
    {
        if (!balls.Contains(ball))
        {
            balls.Add(ball);
        }
    }
    
    public void RemoveBall(BallController ball)
    {
        if (isRespawning) return;
        
        if (balls.Contains(ball))
            balls.Remove(ball);
        
        if (balls.Count == 0 && !isRespawning)
        {
            isRespawning = true;
            GameManager.Instance.LoseLife();
            Invoke(nameof(CreateNewBall), 0.2f);
        }
    }
    
    void CreateNewBall()
    {
        GameObject paddle = GameObject.FindGameObjectWithTag("Platform");
        
        if (paddle == null)
        {
            isRespawning = false;
            return;
        }
        
        if (ballPrefab == null)
        {
            Debug.LogError("ballPrefab не назначен! Перетащите префаб мяча в BallMultiplierManager");
            isRespawning = false;
            return;
        }
        
        GameObject newBallObj = Instantiate(ballPrefab, paddle.transform.position + new Vector3(0, 0.5f, 0), Quaternion.identity);
        newBallObj.name = "Ball";
        
        BallController newController = newBallObj.GetComponent<BallController>();
        if (newController != null)
        {
            newController.paddle = paddle;
            newController.Respawn();
            balls.Add(newController);
        }
        
        isRespawning = false;
    }
}