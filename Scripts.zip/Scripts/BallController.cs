using UnityEngine;
using System;

public class BallController : MonoBehaviour
{
    public float speed = 4f;
    public GameObject paddle;
    public AudioClip bounceClip;
    
    public event Action<BallController> OnBallDestroyed;  
    
    private Rigidbody rb;
    public bool isLaunched = false;
    private float currentSpeed;
    private AudioSource audioSource;
    
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
            audioSource = gameObject.AddComponent<AudioSource>();
        
        if (paddle == null)
            paddle = GameObject.FindGameObjectWithTag("Platform");
        
        rb.velocity = Vector3.zero;
        currentSpeed = speed;
        isLaunched = false;  
        
        FollowPaddle();
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
    }
    
    void Update()
    {
        if (!isLaunched && Input.GetKeyDown(KeyCode.Space))
            Launch();
        
        if (!isLaunched)
            FollowPaddle();
    }
    
    void FollowPaddle()
    {
        if (paddle != null)
        {
            transform.position = new Vector3(
                paddle.transform.position.x,
                paddle.transform.position.y + 0.5f,
                0f
            );
        }
    }
    
    void Launch()
    {
        isLaunched = true;
        Vector3 direction = new Vector3(UnityEngine.Random.Range(-0.5f, 0.5f), 1f, 0f).normalized;
        rb.velocity = direction * currentSpeed;
    }
    
    public void Respawn()
    {
        if (paddle == null)
            paddle = GameObject.FindGameObjectWithTag("Platform");
        
        if (paddle != null)
        {
            isLaunched = false;
            
            if (rb != null)
            {
                rb.velocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
            
            transform.position = new Vector3(
                paddle.transform.position.x,
                paddle.transform.position.y + 0.5f,
                0f
            );
        }
    }
    
    void FixedUpdate()
    {
        if (isLaunched && rb.velocity.magnitude > 0)
        {
            rb.velocity = rb.velocity.normalized * currentSpeed;
        }
    }
    
    void OnCollisionEnter(Collision collision)
    {
        if (bounceClip != null && audioSource != null)
            audioSource.PlayOneShot(bounceClip);
        
        if (collision.gameObject == paddle)
        {
            float hitPos = transform.position.x - paddle.transform.position.x;
            float angle = Mathf.Clamp(hitPos * 1.5f, -0.8f, 0.8f);
            Vector3 newVel = new Vector3(angle, 1f, 0f).normalized;
            rb.velocity = newVel * currentSpeed;
            
            PlatformController paddleCtrl = paddle.GetComponent<PlatformController>();
            if (paddleCtrl != null)
                paddleCtrl.HitAnimation();
        }
        
        Vector3 vel = rb.velocity;
        if (Mathf.Abs(vel.y) < 0.3f)
        {
            vel.y = (vel.y >= 0) ? 0.3f : -0.3f;
            rb.velocity = vel.normalized * currentSpeed;
        }
    }
    
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("BottomBoundary"))
        {
            OnBallDestroyed?.Invoke(this);
            Destroy(gameObject);
        }
    }
}