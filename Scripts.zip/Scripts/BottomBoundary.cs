using UnityEngine;

public class BottomBoundary : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Ball"))
        {
            BallController ball = other.GetComponent<BallController>();
            
            if (ball != null)
            {
                if (BallMultiplierManager.Instance != null)
                {
                    BallMultiplierManager.Instance.RemoveBall(ball);
                }
                else
                {
                    GameManager.Instance.LoseLife();
                }
            }
            
            Destroy(other.gameObject);
        }
    }
}