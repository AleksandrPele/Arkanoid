using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    
    public int lives = 3;
    public int score = 0;
    
    public Text scoreText;
    public Text livesText;
    public GameObject winPanel;
    public GameObject losePanel;
    
    public AudioClip lifeLostClip;
    public AudioClip winClip;
    public AudioClip loseClip;
    
    private AudioSource audioSource;
    private bool isGameOver = false;
    private BallController ball;
    private int bricksCount;
    
    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
        
        audioSource = GetComponent<AudioSource>();
    }
    
    void Start()
    {
        ball = FindObjectOfType<BallController>();
        bricksCount = FindObjectsOfType<Brick>().Length;
        UpdateUI();
        
        if (winPanel != null) winPanel.SetActive(false);
        if (losePanel != null) losePanel.SetActive(false);
        
        Time.timeScale = 1f;
    }
    
    public void AddScore(int value)
    {
        if (isGameOver) return;
        
        int multiplier = 1;
        if (PowerUpManager.Instance != null)
            multiplier = PowerUpManager.Instance.GetScoreMultiplier();
        
        score += value * multiplier;
        UpdateUI();
    }
    
    public void BrickDestroyed()
    {
        bricksCount--;
        if (bricksCount <= 0)
            GameWin();
    }
    
    public void LoseLife()
    {
        if (isGameOver) return;
        if (lives <= 0) return;
        
        lives--;
        UpdateUI();
        
        if (lifeLostClip != null && audioSource != null)
            audioSource.PlayOneShot(lifeLostClip);
        
        if (lives <= 0)
        {
            GameLose();
        }
    }
    
    void GameWin()
    {
        isGameOver = true;
        if (winClip != null && audioSource != null)
            audioSource.PlayOneShot(winClip);
        if (winPanel != null) winPanel.SetActive(true);
        Time.timeScale = 0f;
    }
    
    void GameLose()
    {
        isGameOver = true;
        if (loseClip != null && audioSource != null)
            audioSource.PlayOneShot(loseClip);
        if (losePanel != null) losePanel.SetActive(true);
        Time.timeScale = 0f;
    }
    
    void UpdateUI()
    {
        if (scoreText != null) scoreText.text = "Score: " + score;
        if (livesText != null) livesText.text = "Lives: " + lives;
    }
    
    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
